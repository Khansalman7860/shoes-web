import "./App.css";
import NavBar from "./components/navBar";
import MainContent from "./components/MainContent";
const App = () => {
  return (
    <div>
      <NavBar />
      <MainContent />
    </div>
  );
};

export default App;
